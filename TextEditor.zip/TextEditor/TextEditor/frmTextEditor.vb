﻿'' Author:  Meixiaohan Hu
'' Student ID: 100685179
'' Course Code:  NETD-2202
'' Modified Date: 07-21-2018
'' Description:  This lab is to creat a Windows Forms application that will need to be able to 
''               open, close, edit, save, save As, And create New files (.txt).
''               The application will also require the ability To copy, cut, And paste text.
''               The solution should also allow the user To Exit the program.
Option Strict On
Imports System.IO
Imports System.Drawing.Text


Public Class frmTextEditor



#Region "File"
    ''' <summary>
    ''' OnClickNew event handler creates a new file and clear all the text in the text box
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub OnClickNew(sender As Object, e As EventArgs) Handles mnuMNINew.Click
        Dim Response As MsgBoxResult
        Response = MsgBox("Are you sure you want to start a New Document?",
                              CType(MsgBoxStyle.Question + MsgBoxStyle.YesNo, MsgBoxStyle),
                              "Text Editor")
        If Response = MsgBoxResult.Yes Then
            tbInput.Clear()
            Me.Text = "Text Editor - Untitled"
        End If

    End Sub
    ''' <summary>
    ''' OnClickOpen event handler is used to open the file the user selected in the OpenFileDialog
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub OnClickOpen(sender As Object, e As EventArgs) Handles mnuMNIOpen.Click
        Dim fo As New OpenFileDialog

        fo.Filter = "txt files (*.txt)|*.txt|All files (*,*)|*.*"

        If fo.ShowDialog().Equals(DialogResult.OK) Then
            Dim filename As String
            filename = fo.FileName


            tbInput.Text = GetFileText(New FileStream(filename, FileMode.Open, FileAccess.Read))

            Me.Text = "Text Editor - " & filename

        End If
        MessageBox.Show("File Read is done!")





    End Sub
    ''' <summary>
    ''' OnClickSave event handler is used to save the file in two situations
    ''' If the file path is not known then the SaveFileDialog will be used
    ''' If the file path is known (existing selected file) then there is no need to display the SaveFileDialog
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub OnClickSave(sender As Object, e As EventArgs) Handles mnuMNISave.Click
        Dim path As String = Me.Text.Replace("Text Editor - ", "")

        If File.Exists(path) And path <> "Untitled" Then
            Save(path)
            MessageBox.Show("File has been Saved!")
        Else
            Dim fs As New SaveFileDialog
            fs.Filter = "txt files (*.txt)|*.txt|All files (*,*)|*.*"

            If fs.ShowDialog().Equals(DialogResult.OK) Then
                Dim filePath As String = fs.FileName
                Save(filePath)
                Me.Text = "Text Editor - " & fs.FileName
                MessageBox.Show("File has been Saved!")
            End If

        End If


    End Sub
    ''' <summary>
    ''' OnClickSaveAs is used to save the file and it should always display the SaveFileDialog 
    ''' because you are creating a new file.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub OnClickSaveAs(sender As Object, e As EventArgs) Handles mnuMNISaveAs.Click
        Dim fs As New SaveFileDialog
        fs.Filter = "txt files (*.txt)|*.txt|All files (*,*)|*.*"

        If fs.ShowDialog().Equals(DialogResult.OK) Then
            Save(fs.FileName)
            MessageBox.Show("File Write is done")
            Me.Text = "Text Editor - " & fs.FileName
        End If


    End Sub
    ''' <summary>
    ''' OnClickExit is used to close the aoolication
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub OnClickExit(sender As Object, e As EventArgs) Handles mnuMNIExit.Click
        Me.Close()

    End Sub
#End Region
    ''' <summary>
    ''' OnClickCopy is used to copy the selected text
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
#Region "Edit"
    Private Sub OnClickCopy(sender As Object, e As EventArgs) Handles mnuMNICopy.Click
        My.Computer.Clipboard.SetText(tbInput.SelectedText)
    End Sub

    ''' <summary>
    ''' OnClickCut is used to cut the selected text
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub OnClickCut(sender As Object, e As EventArgs) Handles mnuMNICut.Click
        My.Computer.Clipboard.SetText(tbInput.SelectedText)
        tbInput.SelectedText = ""
    End Sub

    ''' <summary>
    ''' OnClickPaste is used to paste the selected text
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub OnClickPaste(sender As Object, e As EventArgs) Handles mnuMNIPaste.Click
        If My.Computer.Clipboard.ContainsText Then
            tbInput.SelectedText = My.Computer.Clipboard.GetText()
        End If

    End Sub

    Private Sub Timer_Tick(sender As Object, e As EventArgs) Handles Timer.Tick
        lbCharCount.Text = "Characters in the current document: " & tbInput.TextLength.ToString()

    End Sub


#End Region


#Region "Help"
    ''' <summary>
    ''' OnClickAbout event handle shows the information of course code, lab # and inventer's name
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub OnClickAbout(sender As Object, e As EventArgs) Handles mnuMNIAbout.Click
        MessageBox.Show("NETD-2202" & vbLf & "Lab #5" & vbLf & "Meixiaohan Hu", "About")

    End Sub
#End Region

#Region "Method"
    ''' <summary>
    ''' Save function saves the file the user modifying currently
    ''' </summary>
    ''' <param name="filename"></param>
    Private Sub Save(filename As String)

        Dim textOut As New StreamWriter(New FileStream(filename, FileMode.Create, FileAccess.Write))

        textOut.Write(tbInput.Text)

        textOut.Close()
    End Sub


    ''' <summary>
    ''' GetFileText gets the file chosen by the user
    ''' </summary>
    ''' <param name="file">represents the file selected by the user</param>
    ''' <returns></returns>
    Public Shared Function GetFileText(file As FileStream) As String

        Dim textIn As New StreamReader(file)

        Dim textFile As String = textIn.ReadToEnd()
        textIn.Close()
        Return textFile


    End Function



#End Region
End Class
