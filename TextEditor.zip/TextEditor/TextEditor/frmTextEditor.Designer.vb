﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmTextEditor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.mnuMNIFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMNINew = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMNIOpen = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMNISave = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMNISaveAs = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMNIExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMNIEditor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMNICopy = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMNICut = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMNIPaste = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMNIHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMNIAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.ttpTextEditor = New System.Windows.Forms.ToolTip(Me.components)
        Me.tbInput = New System.Windows.Forms.TextBox()
        Me.Timer = New System.Windows.Forms.Timer(Me.components)
        Me.Status = New System.Windows.Forms.StatusStrip()
        Me.lbCharCount = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lbZoom = New System.Windows.Forms.ToolStripStatusLabel()
        Me.mnuMain.SuspendLayout()
        Me.Status.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnuMain
        '
        Me.mnuMain.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMNIFile, Me.mnuMNIEditor, Me.mnuMNIHelp})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Size = New System.Drawing.Size(963, 33)
        Me.mnuMain.TabIndex = 0
        Me.mnuMain.Text = "MenuStrip1"
        '
        'mnuMNIFile
        '
        Me.mnuMNIFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMNINew, Me.mnuMNIOpen, Me.mnuMNISave, Me.mnuMNISaveAs, Me.mnuMNIExit})
        Me.mnuMNIFile.Name = "mnuMNIFile"
        Me.mnuMNIFile.Size = New System.Drawing.Size(50, 29)
        Me.mnuMNIFile.Text = "&File"
        Me.mnuMNIFile.ToolTipText = "Click to choose the New, Open, Save, Save As and Exit options"
        '
        'mnuMNINew
        '
        Me.mnuMNINew.Name = "mnuMNINew"
        Me.mnuMNINew.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.mnuMNINew.Size = New System.Drawing.Size(205, 30)
        Me.mnuMNINew.Text = "&New"
        Me.mnuMNINew.ToolTipText = "Click to create a new text file"
        '
        'mnuMNIOpen
        '
        Me.mnuMNIOpen.Name = "mnuMNIOpen"
        Me.mnuMNIOpen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.mnuMNIOpen.Size = New System.Drawing.Size(205, 30)
        Me.mnuMNIOpen.Text = "&Open"
        Me.mnuMNIOpen.ToolTipText = "Click to select a file to open"
        '
        'mnuMNISave
        '
        Me.mnuMNISave.Name = "mnuMNISave"
        Me.mnuMNISave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnuMNISave.Size = New System.Drawing.Size(205, 30)
        Me.mnuMNISave.Text = "&Save"
        Me.mnuMNISave.ToolTipText = "Click to save the current file"
        '
        'mnuMNISaveAs
        '
        Me.mnuMNISaveAs.Name = "mnuMNISaveAs"
        Me.mnuMNISaveAs.Size = New System.Drawing.Size(205, 30)
        Me.mnuMNISaveAs.Text = "Save &As"
        Me.mnuMNISaveAs.ToolTipText = "Click to save the current file as different types"
        '
        'mnuMNIExit
        '
        Me.mnuMNIExit.Name = "mnuMNIExit"
        Me.mnuMNIExit.Size = New System.Drawing.Size(205, 30)
        Me.mnuMNIExit.Text = "E&xit"
        Me.mnuMNIExit.ToolTipText = "Click to exit the application"
        '
        'mnuMNIEditor
        '
        Me.mnuMNIEditor.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMNICopy, Me.mnuMNICut, Me.mnuMNIPaste})
        Me.mnuMNIEditor.Name = "mnuMNIEditor"
        Me.mnuMNIEditor.Size = New System.Drawing.Size(71, 29)
        Me.mnuMNIEditor.Text = "&Editor"
        Me.mnuMNIEditor.ToolTipText = "Click to choose the Copy, Cut and Paste options"
        '
        'mnuMNICopy
        '
        Me.mnuMNICopy.Name = "mnuMNICopy"
        Me.mnuMNICopy.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.mnuMNICopy.Size = New System.Drawing.Size(200, 30)
        Me.mnuMNICopy.Text = "&Copy"
        Me.mnuMNICopy.ToolTipText = "Click to copy the highlighting text"
        '
        'mnuMNICut
        '
        Me.mnuMNICut.Name = "mnuMNICut"
        Me.mnuMNICut.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.mnuMNICut.Size = New System.Drawing.Size(200, 30)
        Me.mnuMNICut.Text = "Cu&t"
        Me.mnuMNICut.ToolTipText = "Click to cut the highlighting text"
        '
        'mnuMNIPaste
        '
        Me.mnuMNIPaste.Name = "mnuMNIPaste"
        Me.mnuMNIPaste.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.mnuMNIPaste.Size = New System.Drawing.Size(200, 30)
        Me.mnuMNIPaste.Text = "&Paste"
        Me.mnuMNIPaste.ToolTipText = "Click to paste the text to the start point"
        '
        'mnuMNIHelp
        '
        Me.mnuMNIHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuMNIAbout})
        Me.mnuMNIHelp.Name = "mnuMNIHelp"
        Me.mnuMNIHelp.Size = New System.Drawing.Size(61, 29)
        Me.mnuMNIHelp.Text = "Help"
        Me.mnuMNIHelp.ToolTipText = "Click to get help of the text editor"
        '
        'mnuMNIAbout
        '
        Me.mnuMNIAbout.Name = "mnuMNIAbout"
        Me.mnuMNIAbout.Size = New System.Drawing.Size(146, 30)
        Me.mnuMNIAbout.Text = "About"
        Me.mnuMNIAbout.ToolTipText = "Click to show the information about the text editor"
        '
        'tbInput
        '
        Me.tbInput.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbInput.Location = New System.Drawing.Point(0, 33)
        Me.tbInput.Multiline = True
        Me.tbInput.Name = "tbInput"
        Me.tbInput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbInput.Size = New System.Drawing.Size(963, 595)
        Me.tbInput.TabIndex = 2
        Me.ttpTextEditor.SetToolTip(Me.tbInput, "For user to enter and edit the text")
        '
        'Timer
        '
        Me.Timer.Enabled = True
        Me.Timer.Interval = 1
        '
        'Status
        '
        Me.Status.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.Status.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbCharCount, Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.lbZoom})
        Me.Status.Location = New System.Drawing.Point(0, 598)
        Me.Status.Name = "Status"
        Me.Status.Size = New System.Drawing.Size(963, 30)
        Me.Status.TabIndex = 3
        Me.Status.Text = "StatusStrip1"
        '
        'lbCharCount
        '
        Me.lbCharCount.Name = "lbCharCount"
        Me.lbCharCount.Size = New System.Drawing.Size(22, 25)
        Me.lbCharCount.Text = "0"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.AutoSize = False
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 25)
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(866, 25)
        Me.ToolStripStatusLabel2.Spring = True
        '
        'lbZoom
        '
        Me.lbZoom.Name = "lbZoom"
        Me.lbZoom.Size = New System.Drawing.Size(60, 25)
        Me.lbZoom.Text = "Zoom"
        '
        'frmTextEditor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(963, 628)
        Me.Controls.Add(Me.Status)
        Me.Controls.Add(Me.tbInput)
        Me.Controls.Add(Me.mnuMain)
        Me.MainMenuStrip = Me.mnuMain
        Me.MinimumSize = New System.Drawing.Size(985, 684)
        Me.Name = "frmTextEditor"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Text Editor - "
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        Me.Status.ResumeLayout(False)
        Me.Status.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents mnuMain As MenuStrip
    Friend WithEvents mnuMNIFile As ToolStripMenuItem
    Friend WithEvents mnuMNINew As ToolStripMenuItem
    Friend WithEvents mnuMNIOpen As ToolStripMenuItem
    Friend WithEvents mnuMNISave As ToolStripMenuItem
    Friend WithEvents mnuMNISaveAs As ToolStripMenuItem
    Friend WithEvents mnuMNIExit As ToolStripMenuItem
    Friend WithEvents mnuMNIEditor As ToolStripMenuItem
    Friend WithEvents mnuMNICopy As ToolStripMenuItem
    Friend WithEvents mnuMNICut As ToolStripMenuItem
    Friend WithEvents mnuMNIPaste As ToolStripMenuItem
    Friend WithEvents mnuMNIHelp As ToolStripMenuItem
    Friend WithEvents mnuMNIAbout As ToolStripMenuItem
    Friend WithEvents ttpTextEditor As ToolTip
    Friend WithEvents tbInput As TextBox
    Friend WithEvents Timer As Timer
    Friend WithEvents Status As StatusStrip
    Friend WithEvents lbCharCount As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents lbZoom As ToolStripStatusLabel
End Class
