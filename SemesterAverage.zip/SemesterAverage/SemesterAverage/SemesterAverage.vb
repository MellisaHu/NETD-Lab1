﻿Option Strict On
' Name:  Meixiaohan Hu
' Last Modified: June 15, 2018
' Purpose:  This is a form to determine clients' grades in 6 courses in this semester by
'              using a variety of methods. NETD 2202 Lab 2.
'              Emphasizes validation and the use of functions.
Public Class frmSemesterGrades

    Private Const minimumGrade As Double = 0.00     ' The minimum valid grade 
    Private Const maximumGrade As Double = 100.0   ' The maximum valid grade
    ' The array to store the range of the grade
    Private gradeRanges As Integer() =
        {90, 85, 80, 77, 73, 70, 67, 63, 60, 57, 53, 50, 0}
    ' The array to store the range of the letter grade
    Private letterGradeValue As String() =
        {"A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F"}


#Region "Event Handlers"

    Private Sub frmSemesterGrades_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    ''' <summary>
    ''' This button is used to  click to check whether all the entries is valid.
    ''' If all the entries are valid, calculating the average grade of this semester 
    ''' and transfer the letter grade.
    ''' If some of the emtries are not valid, display the corresponding error messages.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim averageGrade As Double = 0.00        ' The average grade of this semester
        Dim flag As Integer = 1                  ' The index to test whether it is the first error input

        ' The array to store the 6 textboxes
        Dim textboxArray As TextBox() =
        {tbCourse1, tbCourse2, tbCourse3, tbCourse4, tbCourse5, tbCourse6}
        ' The array to store the 6 letter lables
        Dim labelArray As Label() =
        {lbCourse1LetterGrade, lbCourse2LetterGrade, lbCourse3LetterGrade, lbCourse4LetterGrade, lbCourse5LetterGrade, lbCourse6LetterGrade}

        ' Clear the error message box
        lbErrorMessage.Text = ""

        ' INPUT

        ' Validate all the Courses input 
        For currentIndex As Integer = 0 To textboxArray.Length - 1
            If ValidateGrade(textboxArray(currentIndex), labelArray(currentIndex)) Then
                ' PROCESSING
                ' Calculate the average grade if all the Courses' input is valid
                averageGrade += 1.0 / (textboxArray.Length) * (Convert.ToDouble(textboxArray(currentIndex).Text))
            Else
                ' Do the first error message input, select and focus on the first offending textbox
                If flag = 1 Then
                    textboxArray(currentIndex).SelectAll()
                    textboxArray(currentIndex).Focus()
                    lbErrorMessage.Text = "ERROR(s)" & vbCrLf
                End If
                lbErrorMessage.Text += "Please ensure that what you input in Course " & currentIndex + 1 & " is a number between " &
                    minimumGrade & " and " & maximumGrade & "." & vbCrLf
                flag = 0
            End If
        Next
        ' OUTPUT
        If flag = 1 Then
            ' Transfer the letter grade of this semester
            lbSemesterAverage.Text = Math.Round(averageGrade, 2).ToString("n2")

            For currentGradeRange As Integer = 0 To gradeRanges.Length - 1
                If Math.Round(averageGrade, 0) >= gradeRanges(currentGradeRange) Then
                    lbSemesterLetterGrade.Text = letterGradeValue(currentGradeRange)
                    currentGradeRange = gradeRanges.Length - 1
                    Exit For
                Else

                End If
            Next
            ' Disable all the textboxes
            tbCourse1.ReadOnly = True
            tbCourse2.ReadOnly = True
            tbCourse3.ReadOnly = True
            tbCourse4.ReadOnly = True
            tbCourse5.ReadOnly = True
            tbCourse6.ReadOnly = True

            ' Disable the Calculate button
            btnCalculate.Enabled = False
            ' Focus on the Reset button
            btnReset.Focus()
        End If
    End Sub

    ''' <summary>
    ''' Clears all textboxes of grades and clear all letter grade labels
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        SetDefaults()
    End Sub
    ''' <summary>
    ''' Clears all textboxes of grades and clear all letter grade labels
    ''' </summary>
    Private Sub SetDefaults()

        ' Clear the contents of all the input text boxes
        tbCourse1.Clear()
        tbCourse2.Clear()
        tbCourse3.Clear()
        tbCourse4.Clear()
        tbCourse5.Clear()
        tbCourse6.Clear()

        'Clear the contents of all labels with letter grades and 
        lbCourse1LetterGrade.Text = String.Empty
        lbCourse2LetterGrade.Text = String.Empty
        lbCourse3LetterGrade.Text = String.Empty
        lbCourse4LetterGrade.Text = String.Empty
        lbCourse5LetterGrade.Text = String.Empty
        lbCourse6LetterGrade.Text = String.Empty

        'Clear the calculated average
        lbSemesterAverage.Text = String.Empty
        lbSemesterLetterGrade.Text = String.Empty

        'Clear the error message
        lbErrorMessage.Text = String.Empty

        ' Focus on the Course 1 textbox and Calculate button
        tbCourse1.Focus()

        ' Enable all the text boxes
        tbCourse1.ReadOnly = False
        tbCourse2.ReadOnly = False
        tbCourse3.ReadOnly = False
        tbCourse4.ReadOnly = False
        tbCourse5.ReadOnly = False
        tbCourse6.ReadOnly = False

        'Enable the Calculate button
        btnCalculate.Enabled = True

    End Sub
    ''' <summary>
    ''' The handler to transfer the valid grade of each course into letter grade when the textboxes lost focus 
    ''' when the textbox lost fouced
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub GradeLostFocus(sender As Object, e As EventArgs) Handles tbCourse1.LostFocus, tbCourse2.LostFocus, tbCourse3.LostFocus, tbCourse4.LostFocus, tbCourse5.LostFocus, tbCourse6.LostFocus
        ' Empty the error message box first
        lbErrorMessage.Text = ""

        ' When textboxes lost focus, operate the ValidateGrade function
        ValidateGrade(tbCourse1, lbCourse1LetterGrade)
        ValidateGrade(tbCourse2, lbCourse2LetterGrade)
        ValidateGrade(tbCourse3, lbCourse3LetterGrade)
        ValidateGrade(tbCourse4, lbCourse4LetterGrade)
        ValidateGrade(tbCourse5, lbCourse5LetterGrade)
        ValidateGrade(tbCourse6, lbCourse6LetterGrade)


    End Sub

    ''' <summary>
    ''' Click to exit the whole application
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
#End Region

#Region "Functions"
    ''' <summary>
    ''' The function use to validate the Courses input and transfer the grade to letter grade
    ''' </summary>
    ''' <param name="tbGradeValue"></param>
    ''' <param name="lbLetterGradeValue"></param>
    ''' <returns></returns>
    Friend Function ValidateGrade(ByRef tbGradeValue As TextBox, ByRef lbLetterGradeValue As Label) As Boolean
        Dim gradeValue As Double                ' The value of the grade          

        ' Validate whether input is empty
        If tbGradeValue.Text <> "" Then
            ' Validate whether input is numeric
            If Double.TryParse(tbGradeValue.Text, gradeValue) Then
                ' Validate whether input is in the range
                If gradeValue >= minimumGrade And gradeValue <= maximumGrade Then
                    ' Transfer the grade to letter grade, if it is valid
                    For currentGradeRange As Integer = 0 To gradeRanges.Length - 1
                        If Math.Round(gradeValue, 0) >= gradeRanges(currentGradeRange) Then
                            lbLetterGradeValue.Text = letterGradeValue(currentGradeRange)
                            currentGradeRange = gradeRanges.Length - 1
                        Else

                        End If
                    Next
                    Return True

                Else
                    ' Outside the range
                    lbErrorMessage.Text += "Please ensure that what you input is a number between " &
                    minimumGrade & " and " & maximumGrade & "." & vbCrLf
                    tbGradeValue.SelectAll()
                    tbGradeValue.Focus()
                    Return False

                End If

            Else
                ' Not numeric
                lbErrorMessage.Text += "Please ensure that what you input is a number between " &
                    minimumGrade & " and " & maximumGrade & "." & vbCrLf
                tbGradeValue.SelectAll()
                tbGradeValue.Focus()
                Return False

            End If

        Else
            Return False

        End If

    End Function
#End Region



End Class
