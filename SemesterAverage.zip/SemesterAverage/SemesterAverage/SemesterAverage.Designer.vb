﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSemesterGrades
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ttpSemesterGradesTips = New System.Windows.Forms.ToolTip(Me.components)
        Me.lbCourse1LetterGrade = New System.Windows.Forms.Label()
        Me.lbErrorMessage = New System.Windows.Forms.Label()
        Me.lbSemesterAverage = New System.Windows.Forms.Label()
        Me.lbSemesterLetterGrade = New System.Windows.Forms.Label()
        Me.lbCourse6LetterGrade = New System.Windows.Forms.Label()
        Me.lbCourse5LetterGrade = New System.Windows.Forms.Label()
        Me.lbCourse4LetterGrade = New System.Windows.Forms.Label()
        Me.lbCourse3LetterGrade = New System.Windows.Forms.Label()
        Me.lbCourse2LetterGrade = New System.Windows.Forms.Label()
        Me.tbCourse1 = New System.Windows.Forms.TextBox()
        Me.tbCourse2 = New System.Windows.Forms.TextBox()
        Me.tbCourse3 = New System.Windows.Forms.TextBox()
        Me.tbCourse4 = New System.Windows.Forms.TextBox()
        Me.tbCourse5 = New System.Windows.Forms.TextBox()
        Me.tbCourse6 = New System.Windows.Forms.TextBox()
        Me.lbCourse1 = New System.Windows.Forms.Label()
        Me.lbCourse2 = New System.Windows.Forms.Label()
        Me.lbCourse6 = New System.Windows.Forms.Label()
        Me.lbCourse5 = New System.Windows.Forms.Label()
        Me.lbCourse4 = New System.Windows.Forms.Label()
        Me.lbCourse3 = New System.Windows.Forms.Label()
        Me.lbSemester = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.AutoSize = True
        Me.btnCalculate.Location = New System.Drawing.Point(97, 551)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(85, 30)
        Me.btnCalculate.TabIndex = 22
        Me.btnCalculate.Text = "&Calculate"
        Me.ttpSemesterGradesTips.SetToolTip(Me.btnCalculate, "Click to Calculate the average grade")
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.AutoSize = True
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(197, 551)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(85, 30)
        Me.btnReset.TabIndex = 23
        Me.btnReset.Text = "&Reset"
        Me.ttpSemesterGradesTips.SetToolTip(Me.btnReset, "Click to reset form")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.AutoSize = True
        Me.btnExit.Location = New System.Drawing.Point(296, 551)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(85, 30)
        Me.btnExit.TabIndex = 24
        Me.btnExit.Text = "E&xit"
        Me.ttpSemesterGradesTips.SetToolTip(Me.btnExit, "Click to exit the application")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lbCourse1LetterGrade
        '
        Me.lbCourse1LetterGrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbCourse1LetterGrade.Location = New System.Drawing.Point(260, 29)
        Me.lbCourse1LetterGrade.Name = "lbCourse1LetterGrade"
        Me.lbCourse1LetterGrade.Size = New System.Drawing.Size(120, 26)
        Me.lbCourse1LetterGrade.TabIndex = 2
        Me.lbCourse1LetterGrade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpSemesterGradesTips.SetToolTip(Me.lbCourse1LetterGrade, "Display the modifier of grade in Course 1")
        '
        'lbErrorMessage
        '
        Me.lbErrorMessage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbErrorMessage.Location = New System.Drawing.Point(15, 293)
        Me.lbErrorMessage.Name = "lbErrorMessage"
        Me.lbErrorMessage.Size = New System.Drawing.Size(366, 250)
        Me.lbErrorMessage.TabIndex = 21
        Me.ttpSemesterGradesTips.SetToolTip(Me.lbErrorMessage, "Dispaly the error message")
        '
        'lbSemesterAverage
        '
        Me.lbSemesterAverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbSemesterAverage.Location = New System.Drawing.Point(130, 258)
        Me.lbSemesterAverage.Name = "lbSemesterAverage"
        Me.lbSemesterAverage.Size = New System.Drawing.Size(120, 26)
        Me.lbSemesterAverage.TabIndex = 19
        Me.lbSemesterAverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpSemesterGradesTips.SetToolTip(Me.lbSemesterAverage, "Display the average grade in this semester")
        '
        'lbSemesterLetterGrade
        '
        Me.lbSemesterLetterGrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbSemesterLetterGrade.Location = New System.Drawing.Point(261, 258)
        Me.lbSemesterLetterGrade.Name = "lbSemesterLetterGrade"
        Me.lbSemesterLetterGrade.Size = New System.Drawing.Size(120, 26)
        Me.lbSemesterLetterGrade.TabIndex = 20
        Me.lbSemesterLetterGrade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpSemesterGradesTips.SetToolTip(Me.lbSemesterLetterGrade, "Display the modifier of average grade in this semester")
        '
        'lbCourse6LetterGrade
        '
        Me.lbCourse6LetterGrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbCourse6LetterGrade.Location = New System.Drawing.Point(261, 221)
        Me.lbCourse6LetterGrade.Name = "lbCourse6LetterGrade"
        Me.lbCourse6LetterGrade.Size = New System.Drawing.Size(120, 26)
        Me.lbCourse6LetterGrade.TabIndex = 17
        Me.lbCourse6LetterGrade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpSemesterGradesTips.SetToolTip(Me.lbCourse6LetterGrade, "Display the modifier of grade in Course 6")
        '
        'lbCourse5LetterGrade
        '
        Me.lbCourse5LetterGrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbCourse5LetterGrade.Location = New System.Drawing.Point(261, 183)
        Me.lbCourse5LetterGrade.Name = "lbCourse5LetterGrade"
        Me.lbCourse5LetterGrade.Size = New System.Drawing.Size(120, 26)
        Me.lbCourse5LetterGrade.TabIndex = 14
        Me.lbCourse5LetterGrade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpSemesterGradesTips.SetToolTip(Me.lbCourse5LetterGrade, "Display the modifier of grade in Course 5")
        '
        'lbCourse4LetterGrade
        '
        Me.lbCourse4LetterGrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbCourse4LetterGrade.Location = New System.Drawing.Point(261, 144)
        Me.lbCourse4LetterGrade.Name = "lbCourse4LetterGrade"
        Me.lbCourse4LetterGrade.Size = New System.Drawing.Size(120, 26)
        Me.lbCourse4LetterGrade.TabIndex = 11
        Me.lbCourse4LetterGrade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpSemesterGradesTips.SetToolTip(Me.lbCourse4LetterGrade, "Display the modifier of grade in Course 4")
        '
        'lbCourse3LetterGrade
        '
        Me.lbCourse3LetterGrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbCourse3LetterGrade.Location = New System.Drawing.Point(261, 105)
        Me.lbCourse3LetterGrade.Name = "lbCourse3LetterGrade"
        Me.lbCourse3LetterGrade.Size = New System.Drawing.Size(120, 26)
        Me.lbCourse3LetterGrade.TabIndex = 8
        Me.lbCourse3LetterGrade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpSemesterGradesTips.SetToolTip(Me.lbCourse3LetterGrade, "Display the modifier of grade in Course 3")
        '
        'lbCourse2LetterGrade
        '
        Me.lbCourse2LetterGrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbCourse2LetterGrade.Location = New System.Drawing.Point(261, 68)
        Me.lbCourse2LetterGrade.Name = "lbCourse2LetterGrade"
        Me.lbCourse2LetterGrade.Size = New System.Drawing.Size(120, 26)
        Me.lbCourse2LetterGrade.TabIndex = 5
        Me.lbCourse2LetterGrade.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpSemesterGradesTips.SetToolTip(Me.lbCourse2LetterGrade, "Display the modifier of grade in Course 2")
        '
        'tbCourse1
        '
        Me.tbCourse1.Location = New System.Drawing.Point(130, 29)
        Me.tbCourse1.Name = "tbCourse1"
        Me.tbCourse1.Size = New System.Drawing.Size(120, 26)
        Me.tbCourse1.TabIndex = 1
        Me.tbCourse1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttpSemesterGradesTips.SetToolTip(Me.tbCourse1, "Enter the grade of the Course 1")
        '
        'tbCourse2
        '
        Me.tbCourse2.Location = New System.Drawing.Point(130, 68)
        Me.tbCourse2.Name = "tbCourse2"
        Me.tbCourse2.Size = New System.Drawing.Size(120, 26)
        Me.tbCourse2.TabIndex = 4
        Me.tbCourse2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttpSemesterGradesTips.SetToolTip(Me.tbCourse2, "Enter the grade of the Course 2")
        '
        'tbCourse3
        '
        Me.tbCourse3.Location = New System.Drawing.Point(130, 105)
        Me.tbCourse3.Name = "tbCourse3"
        Me.tbCourse3.Size = New System.Drawing.Size(120, 26)
        Me.tbCourse3.TabIndex = 7
        Me.tbCourse3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttpSemesterGradesTips.SetToolTip(Me.tbCourse3, "Enter the grade of the Course 3")
        '
        'tbCourse4
        '
        Me.tbCourse4.Location = New System.Drawing.Point(130, 144)
        Me.tbCourse4.Name = "tbCourse4"
        Me.tbCourse4.Size = New System.Drawing.Size(120, 26)
        Me.tbCourse4.TabIndex = 10
        Me.tbCourse4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttpSemesterGradesTips.SetToolTip(Me.tbCourse4, "Enter the grade of the Course 4")
        '
        'tbCourse5
        '
        Me.tbCourse5.Location = New System.Drawing.Point(130, 183)
        Me.tbCourse5.Name = "tbCourse5"
        Me.tbCourse5.Size = New System.Drawing.Size(120, 26)
        Me.tbCourse5.TabIndex = 13
        Me.tbCourse5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttpSemesterGradesTips.SetToolTip(Me.tbCourse5, "Enter the grade of the Course 5")
        '
        'tbCourse6
        '
        Me.tbCourse6.Location = New System.Drawing.Point(130, 221)
        Me.tbCourse6.Name = "tbCourse6"
        Me.tbCourse6.Size = New System.Drawing.Size(120, 26)
        Me.tbCourse6.TabIndex = 16
        Me.tbCourse6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ttpSemesterGradesTips.SetToolTip(Me.tbCourse6, "Enter the grade of the Course 6")
        '
        'lbCourse1
        '
        Me.lbCourse1.Location = New System.Drawing.Point(24, 31)
        Me.lbCourse1.Name = "lbCourse1"
        Me.lbCourse1.Size = New System.Drawing.Size(100, 23)
        Me.lbCourse1.TabIndex = 0
        Me.lbCourse1.Text = "Course &1:"
        Me.lbCourse1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbCourse2
        '
        Me.lbCourse2.Location = New System.Drawing.Point(24, 70)
        Me.lbCourse2.Name = "lbCourse2"
        Me.lbCourse2.Size = New System.Drawing.Size(100, 23)
        Me.lbCourse2.TabIndex = 3
        Me.lbCourse2.Text = "Course &2:"
        Me.lbCourse2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbCourse6
        '
        Me.lbCourse6.Location = New System.Drawing.Point(24, 223)
        Me.lbCourse6.Name = "lbCourse6"
        Me.lbCourse6.Size = New System.Drawing.Size(100, 23)
        Me.lbCourse6.TabIndex = 15
        Me.lbCourse6.Text = "Course &6:"
        Me.lbCourse6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbCourse5
        '
        Me.lbCourse5.Location = New System.Drawing.Point(24, 185)
        Me.lbCourse5.Name = "lbCourse5"
        Me.lbCourse5.Size = New System.Drawing.Size(100, 23)
        Me.lbCourse5.TabIndex = 12
        Me.lbCourse5.Text = "Course &5:"
        Me.lbCourse5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbCourse4
        '
        Me.lbCourse4.Location = New System.Drawing.Point(24, 146)
        Me.lbCourse4.Name = "lbCourse4"
        Me.lbCourse4.Size = New System.Drawing.Size(100, 23)
        Me.lbCourse4.TabIndex = 9
        Me.lbCourse4.Text = "Course &4:"
        Me.lbCourse4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbCourse3
        '
        Me.lbCourse3.Location = New System.Drawing.Point(24, 107)
        Me.lbCourse3.Name = "lbCourse3"
        Me.lbCourse3.Size = New System.Drawing.Size(100, 23)
        Me.lbCourse3.TabIndex = 6
        Me.lbCourse3.Text = "Course &3:"
        Me.lbCourse3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbSemester
        '
        Me.lbSemester.Location = New System.Drawing.Point(24, 260)
        Me.lbSemester.Name = "lbSemester"
        Me.lbSemester.Size = New System.Drawing.Size(100, 23)
        Me.lbSemester.TabIndex = 18
        Me.lbSemester.Text = "Semester:"
        Me.lbSemester.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'frmSemesterGrades
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(393, 593)
        Me.Controls.Add(Me.tbCourse6)
        Me.Controls.Add(Me.tbCourse5)
        Me.Controls.Add(Me.tbCourse4)
        Me.Controls.Add(Me.tbCourse3)
        Me.Controls.Add(Me.tbCourse2)
        Me.Controls.Add(Me.tbCourse1)
        Me.Controls.Add(Me.lbCourse2LetterGrade)
        Me.Controls.Add(Me.lbCourse3LetterGrade)
        Me.Controls.Add(Me.lbCourse4LetterGrade)
        Me.Controls.Add(Me.lbCourse5LetterGrade)
        Me.Controls.Add(Me.lbCourse6LetterGrade)
        Me.Controls.Add(Me.lbSemesterLetterGrade)
        Me.Controls.Add(Me.lbSemesterAverage)
        Me.Controls.Add(Me.lbErrorMessage)
        Me.Controls.Add(Me.lbCourse1LetterGrade)
        Me.Controls.Add(Me.lbSemester)
        Me.Controls.Add(Me.lbCourse3)
        Me.Controls.Add(Me.lbCourse4)
        Me.Controls.Add(Me.lbCourse5)
        Me.Controls.Add(Me.lbCourse6)
        Me.Controls.Add(Me.lbCourse2)
        Me.Controls.Add(Me.lbCourse1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSemesterGrades"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Semester Grades"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ttpSemesterGradesTips As ToolTip
    Friend WithEvents lbCourse1 As Label
    Friend WithEvents lbCourse2 As Label
    Friend WithEvents lbCourse6 As Label
    Friend WithEvents lbCourse5 As Label
    Friend WithEvents lbCourse4 As Label
    Friend WithEvents lbCourse3 As Label
    Friend WithEvents lbSemester As Label
    Friend WithEvents lbCourse1LetterGrade As Label
    Friend WithEvents lbErrorMessage As Label
    Friend WithEvents lbSemesterAverage As Label
    Friend WithEvents lbSemesterLetterGrade As Label
    Friend WithEvents lbCourse6LetterGrade As Label
    Friend WithEvents lbCourse5LetterGrade As Label
    Friend WithEvents lbCourse4LetterGrade As Label
    Friend WithEvents lbCourse3LetterGrade As Label
    Friend WithEvents lbCourse2LetterGrade As Label
    Friend WithEvents tbCourse1 As TextBox
    Friend WithEvents tbCourse2 As TextBox
    Friend WithEvents tbCourse3 As TextBox
    Friend WithEvents tbCourse4 As TextBox
    Friend WithEvents tbCourse5 As TextBox
    Friend WithEvents tbCourse6 As TextBox
End Class
