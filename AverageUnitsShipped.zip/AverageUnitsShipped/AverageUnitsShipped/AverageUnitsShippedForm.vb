﻿Option Strict On
' Title: Average Units Shipped
' Name: Meixiaohan Hu
' Date Modified: May 25, 2018
' Description: This VB application is used to calculate 
'              average number of units shipped per week.

Public Class frmAverageUnitsShipped

    Const NumberofDays As Integer = 7     ' The number of days to average
    Dim currentDay As Integer = 1         ' Trace the current day
    Dim unitsShipped(7) As Integer        ' Array storing the number of units shipped



    ''' <summary>
    ''' This useful event handler closes the form.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Me.Close()

    End Sub

    ''' <summary>
    ''' This event handler is used to enter 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        Const MaximumEntryValue As Integer = 1000
        Const MinimumEntryValue As Integer = 0
        Dim currentEntry As Integer
        Dim runningTotal As Integer = 0
        Dim average As Double = 0.0

        ' INPUT

        If Integer.TryParse(txtUnitsShippedEnter.Text, currentEntry) Then

            If (currentEntry >= MinimumEntryValue) And (currentEntry <= MaximumEntryValue) Then

                ' PROCESSING

                txtUnitsShippedEnter.Text = ""

                unitsShipped(currentDay - 1) = currentEntry


                txtUnitsShippedDisplay.Text += currentEntry.ToString & vbCrLf

                If currentDay = 7 Then

                    For dayCounter As Integer = 1 To NumberofDays

                        runningTotal += unitsShipped(dayCounter - 1)

                    Next

                    average = CDbl(runningTotal / NumberofDays)

                    txtUnitsShippedEnter.ReadOnly = True
                    btnEnter.Enabled = False
                    lblAverageDisplay.Text = Math.Round(average, 2).ToString()
                    btnReset.Focus()

                End If

                currentDay = currentDay + 1

                If currentDay <= 7 Then

                    lblDay.Text = "Day " & currentDay

                Else

                    lblDay.Text = "Day 7"

                End If

                ' OUTPUT
            Else
                ' The entry in txtUnitsShippedEntry was out-of-bounds
                MessageBox.Show("Your units shipped must be between " & MinimumEntryValue _
                                & " and" & MaximumEntryValue & ".")
                txtUnitsShippedEnter.SelectAll()
                txtUnitsShippedEnter.Focus()
            End If
        Else
            ' The entry in txtUnitsShippedEntry was not a whole number
            MessageBox.Show("Please enter your units shipped as a whole number.")
            txtUnitsShippedEnter.SelectAll()
            txtUnitsShippedEnter.Focus()
        End If

    End Sub

    ''' <summary>
    ''' This useful event handler reset the all entries
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ' Clear the input textbox
        txtUnitsShippedEnter.Text = ""
        txtUnitsShippedDisplay.Text = ""

        ' Clear the calculated label
        lblAverageDisplay.Text = ""

        ' Reset the label day back to Day 1
        currentDay = 1
        lblDay.Text = "Day " & currentDay

        'Focus on the input textbox delete the read-only property
        txtUnitsShippedEnter.Focus()
        txtUnitsShippedEnter.ReadOnly = False

        'Enable the enter btton
        btnEnter.Enabled = True

    End Sub
End Class
