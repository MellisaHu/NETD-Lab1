﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAverageUnitsShipped
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblUnits = New System.Windows.Forms.Label()
        Me.txtUnitsShippedEnter = New System.Windows.Forms.TextBox()
        Me.lblDay = New System.Windows.Forms.Label()
        Me.txtUnitsShippedDisplay = New System.Windows.Forms.TextBox()
        Me.lblAverageDisplay = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ttpUintsShippedTips = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblUnits
        '
        Me.lblUnits.Location = New System.Drawing.Point(52, 21)
        Me.lblUnits.Name = "lblUnits"
        Me.lblUnits.Size = New System.Drawing.Size(73, 23)
        Me.lblUnits.TabIndex = 0
        Me.lblUnits.Text = "&Units:"
        Me.lblUnits.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtUnitsShippedEnter
        '
        Me.txtUnitsShippedEnter.Location = New System.Drawing.Point(130, 21)
        Me.txtUnitsShippedEnter.Name = "txtUnitsShippedEnter"
        Me.txtUnitsShippedEnter.Size = New System.Drawing.Size(76, 26)
        Me.txtUnitsShippedEnter.TabIndex = 1
        Me.ttpUintsShippedTips.SetToolTip(Me.txtUnitsShippedEnter, "Enter the units shipped for the day")
        '
        'lblDay
        '
        Me.lblDay.Location = New System.Drawing.Point(214, 21)
        Me.lblDay.Name = "lblDay"
        Me.lblDay.Size = New System.Drawing.Size(75, 23)
        Me.lblDay.TabIndex = 2
        Me.lblDay.Text = "Day 1"
        Me.lblDay.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtUnitsShippedDisplay
        '
        Me.txtUnitsShippedDisplay.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.txtUnitsShippedDisplay.Location = New System.Drawing.Point(52, 55)
        Me.txtUnitsShippedDisplay.Multiline = True
        Me.txtUnitsShippedDisplay.Name = "txtUnitsShippedDisplay"
        Me.txtUnitsShippedDisplay.ReadOnly = True
        Me.txtUnitsShippedDisplay.Size = New System.Drawing.Size(237, 150)
        Me.txtUnitsShippedDisplay.TabIndex = 3
        Me.ttpUintsShippedTips.SetToolTip(Me.txtUnitsShippedDisplay, "All daily units shipped dipalyed here")
        '
        'lblAverageDisplay
        '
        Me.lblAverageDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverageDisplay.Location = New System.Drawing.Point(52, 215)
        Me.lblAverageDisplay.Name = "lblAverageDisplay"
        Me.lblAverageDisplay.Size = New System.Drawing.Size(237, 23)
        Me.lblAverageDisplay.TabIndex = 4
        Me.lblAverageDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpUintsShippedTips.SetToolTip(Me.lblAverageDisplay, "dispaly the average of the units shipped")
        '
        'btnEnter
        '
        Me.btnEnter.AutoSize = True
        Me.btnEnter.Location = New System.Drawing.Point(20, 251)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(90, 30)
        Me.btnEnter.TabIndex = 5
        Me.btnEnter.Text = "&Enter"
        Me.ttpUintsShippedTips.SetToolTip(Me.btnEnter, "Click to enter this day's units shipped")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.AutoSize = True
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(130, 251)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(90, 30)
        Me.btnReset.TabIndex = 6
        Me.btnReset.Text = "&Reset"
        Me.ttpUintsShippedTips.SetToolTip(Me.btnReset, "Click to reset all entries")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.AutoSize = True
        Me.btnExit.Location = New System.Drawing.Point(237, 251)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(90, 30)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "E&xit"
        Me.ttpUintsShippedTips.SetToolTip(Me.btnExit, "Click to close the application")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmAverageUnitsShipped
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(346, 295)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblAverageDisplay)
        Me.Controls.Add(Me.txtUnitsShippedDisplay)
        Me.Controls.Add(Me.lblDay)
        Me.Controls.Add(Me.txtUnitsShippedEnter)
        Me.Controls.Add(Me.lblUnits)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAverageUnitsShipped"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Shipped"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblUnits As Label
    Friend WithEvents txtUnitsShippedEnter As TextBox
    Friend WithEvents lblDay As Label
    Friend WithEvents txtUnitsShippedDisplay As TextBox
    Friend WithEvents lblAverageDisplay As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ttpUintsShippedTips As ToolTip
End Class
