﻿'' Author:  Meixiaohan Hu
'' Student ID: 100685179
'' Course Code:  NETD-2202
'' Modified Date: 08-01-2018
'' Description:  This lab is to creat a Windows MDI application that will need to be able to open, close, edit, save, save as, And create New files (.txt).
''               The application will also require the ability To copy, cut, And paste text.
''               The solution should also allow the user To Exit the program.
Option Strict On
Imports System.Drawing.Text
Imports System.IO


Public Class frmMain
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Me.Width <> 659 Then
            lbDescription.Width = Me.Width - 190
        End If

    End Sub
    Dim closeChild As Boolean = False
#Region "Timer & Toolbar"
    ''' <summary>
    ''' This handler event is used to calculate the current date, time and the humber of the opened child forms
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        sbMain.Items("lbDate").Text = DateTime.Today.ToShortDateString()
        sbMain.Items("lbTime").Text = DateTime.Now.ToShortTimeString()

        sbMain.Items("lbDescription").Text = "The number of current opened forms are: " & If(closeChild, Me.MdiChildren.Count - 1, Me.MdiChildren.Count)

    End Sub
    ''' <summary>
    ''' This handler event is used to create new Text Editor child form
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click, mnuNew.Click
        Dim TextEditorForm As New frmTextEditor
        TextEditorForm.MdiParent = Me
        TextEditorForm.Show()
    End Sub
    ''' <summary>
    ''' This handler event is used to open a file in the Text Editor child form
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnOpen_Click(sender As Object, e As EventArgs) Handles mnuOpen.Click, btnOpen.Click

        Dim fo As New OpenFileDialog

        fo.Filter = "txt files (*.txt)|*.txt|All files (*,*)|*.*"

        If fo.ShowDialog().Equals(DialogResult.OK) Then

            Dim TextEditorForm As New frmTextEditor
            TextEditorForm.MdiParent = Me

            Dim filename As String
            filename = fo.FileName

            TextEditorForm.tbInput.Text = GetFileText(New FileStream(filename, FileMode.Open, FileAccess.Read))
            TextEditorForm.Text = filename
            TextEditorForm.Show()

            MessageBox.Show("The File has been read!!!")

        End If


    End Sub
    ''' <summary>
    ''' This handler event is used to save the selected child form 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click, mnuSave.Click
        Dim activeForm As Form = Me.ActiveMdiChild
        Dim averageUnitForm As New frmAverageUnitsShippedEmployee

        If activeForm.GetType() <> averageUnitForm.GetType() Then
            Dim path As String = activeForm.Text

            If File.Exists(path) And path <> "Text Editor" Then
                Save(path)
                MessageBox.Show("File has been Saved!")
            Else
                Dim fs As New SaveFileDialog
                fs.Filter = "txt files (*.txt)|*.txt|All files (*,*)|*.*"

                If fs.ShowDialog().Equals(DialogResult.OK) Then
                    Dim filePath As String = fs.FileName
                    Save(filePath)
                    activeForm.Text = fs.FileName
                    MessageBox.Show("File has been Saved!")
                End If

            End If
        End If

    End Sub
#End Region
#Region "File"
    ''' <summary>
    ''' This event handler used to click to exit the application
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Me.Close()
    End Sub

    Private Sub mnuNew_Click(sender As Object, e As EventArgs)
        Dim TextEditorForm As New frmTextEditor
        TextEditorForm.MdiParent = Me
        TextEditorForm.Show()
    End Sub
    ''' <summary>
    ''' This handler event is used to open a file in the Text Editor child form
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuOpen_Click(sender As Object, e As EventArgs)

    End Sub
    ''' <summary>
    ''' This handler event is used to save a file in the Text Editor child form
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuSave_Click(sender As Object, e As EventArgs)

    End Sub
    ''' <summary>
    ''' This handler event is used to save the selected file as a new file 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuSaveAs_Click(sender As Object, e As EventArgs) Handles mnuSaveAs.Click
        Dim activeForm As Form = Me.ActiveMdiChild
        Dim averageUnitForm As New frmAverageUnitsShippedEmployee

        If ActiveForm.GetType() <> averageUnitForm.GetType() Then
            Dim fs As New SaveFileDialog
            fs.Filter = "txt files (*.txt)|*.txt|All files (*,*)|*.*"

            If fs.ShowDialog().Equals(DialogResult.OK) Then
                Save(fs.FileName)
                MessageBox.Show("File Write is done")
                ActiveForm.Text = fs.FileName
            End If
        End If


    End Sub
    ''' <summary>
    ''' This handler event is used to close the selected child form 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuClose_Click(sender As Object, e As EventArgs) Handles mnuClose.Click
        Dim activeForm As Form = Me.ActiveMdiChild
        closeChild = True
        If activeForm IsNot Nothing Then
            activeForm.Close()
            closeChild = False
        End If

    End Sub



#End Region
#Region "Editor"
    ''' <summary>
    ''' This handler event is used to cut the selected text
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuCut_Click(sender As Object, e As EventArgs) Handles mnuCut.Click
        Dim activeForm As Form = Me.ActiveMdiChild
        Dim tbInput As TextBox = CType(activeForm.ActiveControl, TextBox)
        My.Computer.Clipboard.SetText(tbInput.SelectedText)
        tbInput.SelectedText = ""
    End Sub
    ''' <summary>
    ''' This handler event is used to copy the selected text
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuCopy_Click(sender As Object, e As EventArgs) Handles mnuCopy.Click
        Dim activeForm As Form = Me.ActiveMdiChild
        Dim tbInput As TextBox = CType(activeForm.ActiveControl, TextBox)
        My.Computer.Clipboard.SetText(tbInput.SelectedText)
    End Sub
    ''' <summary>
    ''' This handler event is used to paste the selected text
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuPaste_Click(sender As Object, e As EventArgs) Handles mnuPaste.Click
        Dim activeForm As Form = Me.ActiveMdiChild
        Dim tbInput As TextBox = CType(activeForm.ActiveControl, TextBox)
        If My.Computer.Clipboard.ContainsText Then
            tbInput.SelectedText = My.Computer.Clipboard.GetText()
        End If
    End Sub
    ''' <summary>
    ''' This handler event is used to select all the text in the selected child form
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub SelectAllToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectAllToolStripMenuItem.Click
        Dim activeForm As Form = Me.ActiveMdiChild
        Dim tbInput As TextBox = CType(activeForm.ActiveControl, TextBox)
        tbInput.SelectAll()
    End Sub
#End Region
#Region "Windows"
    ''' <summary>
    ''' This handler event is used to arrange the child forms as the cascade order
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuCascade_Click(sender As Object, e As EventArgs) Handles mnuCascade.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub
    ''' <summary>
    ''' This handler event is used to arrange the child forms as the horizontal order
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuTileHorizontal_Click(sender As Object, e As EventArgs) Handles mnuTileHorizontal.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub
    ''' <summary>
    ''' This handler event is used to arrange the child forms as the vertical order
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuTileVertical_Click(sender As Object, e As EventArgs) Handles mnuTileVertical.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub
    ''' <summary>
    ''' This handler event is used to open the new form "frmAverageUnitsShippedEmployee"
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuAverageUnits_Click(sender As Object, e As EventArgs) Handles mnuAverageUnits.Click
        Dim averageUnits As New frmAverageUnitsShippedEmployee
        averageUnits.MdiParent = Me
        averageUnits.Show()
    End Sub
#End Region
#Region "Help"
    ''' <summary>
    ''' This handler event is used to display the information about the inventor of this application
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click
        MessageBox.Show("NETD-2202" & vbLf & vbLf & "Final Project" & vbLf & vbLf & "Meixiaohan Hu" _
         & vbLf & vbLf & "100685179", "About this application")
    End Sub


#End Region
#Region "Method"
    ''' <summary>
    ''' Save function saves the file the user modifying currently
    ''' </summary>
    ''' <param name="filename"></param>
    Private Sub Save(filename As String)

        Dim activeForm As Form = Me.ActiveMdiChild
        Dim textOut As New StreamWriter(New FileStream(filename, FileMode.Create, FileAccess.Write))

        textOut.Write(activeForm.Controls(0).Text)

        textOut.Close()
    End Sub


    ''' <summary>
    ''' GetFileText gets the file chosen by the user
    ''' </summary>
    ''' <param name="file">represents the file selected by the user</param>
    ''' <returns></returns>
    Public Function GetFileText(file As FileStream) As String

        Dim textIn As New StreamReader(file)

        Dim textFile As String = textIn.ReadToEnd()
        textIn.Close()
        Return textFile


    End Function

    Private Sub lbDescription_Click(sender As Object, e As EventArgs) Handles lbDescription.Click
        MessageBox.Show(lbDescription.Width.ToString() & " " & Me.Width.ToString())
    End Sub





#End Region
End Class
