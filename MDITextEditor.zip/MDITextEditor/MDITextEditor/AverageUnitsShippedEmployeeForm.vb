﻿Option Strict On
' Title: Average Units Shipped
' Name: Meixiaohan Hu
' Date Modified: June 25, 2018
' Description: This VB application is used to calculate 
'              average number of units shipped per day from three employees
'              and calculate the per day average of all these employees.

Public Class frmAverageUnitsShippedEmployee

    Const NumberofDays As Integer = 7          ' The number of days to average
    Const NumberofEmployees As Integer = 3     ' The number of employees to average
    Const MaximumEntryValue As Integer = 1000  ' The maximum valid value of the entry 
    Const MinimumEntryValue As Integer = 0     ' The minimum valid value of the entry

    Dim currentDay As Integer = 1              ' Trace the current day
    Dim currentEmployee As Integer = 1         ' Trace the current employee
    Dim currentEntry As Integer                ' The value of the current input
    Dim totalAverage As Double = 0.0           ' The sum of the average Shipped from 3 employees
    Dim dayAverage As Double = 0.0             ' The average of the average Shipped from 3 employees
    Dim unitsShipped(NumberofDays, NumberofEmployees) As Integer             ' Array storing the number of units shipped


    ''' <summary>
    ''' Updates the label with the current day for entry
    ''' </summary>
    ''' <param name="currentDay"></param>
    Private Sub UpdateDay(currentDay As Integer)

        If currentDay > NumberofDays Then
            ' The current day number is greater than the number of the days in a week
            lbDay.Text = "Done"
        Else
            ' Update the current day
            lbDay.Text = "Day " & currentDay.ToString
        End If
    End Sub


    ''' <summary>
    ''' Takes in a textbox and returns true if the textbox whithin is an integer between 0 and 1000
    ''' </summary>
    ''' <param name="tbEntryBox">Textbox to valid</param>
    ''' <returns></returns>
    Private Function IsValidEntry(ByRef tbEntryBox As TextBox) As Boolean
        ' If the input is empty or numeric
        If Integer.TryParse(tbUnitsShippedEnter.Text, currentEntry) Then
            ' If the input is in the valid range
            If (currentEntry >= MinimumEntryValue) And (currentEntry <= MaximumEntryValue) Then
                Return True

            Else
                ' The entry in txtUnitsShippedEntry was out-of-bounds
                MessageBox.Show("Your units shipped must be between " & MinimumEntryValue _
                                & " and" & MaximumEntryValue & ".")
                tbUnitsShippedEnter.SelectAll()
                tbUnitsShippedEnter.Focus()
                Return False

            End If
        Else
            ' The entry in txtUnitsShippedEntry was not a whole number
            MessageBox.Show("Please enter your units shipped as a whole number.")
            tbUnitsShippedEnter.SelectAll()
            tbUnitsShippedEnter.Focus()
            Return False

        End If
    End Function

    ''' <summary>
    ''' This useful event handler closes the form.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Me.Close()    ' Close the application

    End Sub

    ''' <summary>
    ''' This event handler is used to enter 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        Dim runningTotal As Integer = 0     ' The total shipped of the current employee
        Dim average As Double = 0.0         ' The average shipped of the current employee

        ' The array to store the labels: lbEmployee1, lbEmployee2, lbEmployee3
        Dim employeeArray As Label() = {lbEmployee1, lbEmployee2, lbEmployee3}
        ' The array to store the labels: lbAverageEmployee1, lbAverageEmployee2, lbAverageEmployee3
        Dim employeeAverage As Label() = {lbAverageEmployee1, lbAverageEmployee2, lbAverageEmployee3}
        ' The array to store the textboxes: tbUnitsShippedEmployee1, tbUnitsShippedEmployee2, tbUnitsShippedEmployee3
        Dim employeeUnitesShipped As TextBox() =
            {tbUnitsShippedEmployee1, tbUnitsShippedEmployee2, tbUnitsShippedEmployee3}

        ' INPUT
        If IsValidEntry(tbUnitsShippedEnter) Then

            currentEntry = CInt(tbUnitsShippedEnter.Text)    ' Change the enter value into integer

            tbUnitsShippedEnter.Text = ""                    ' Empty the entry box

            ' Store the current entry into the unitsShipped(currentDay - 1, currentEmployee - 1) array
            unitsShipped(currentDay - 1, currentEmployee - 1) = currentEntry

            ' store the currentEntry string into the current employee textbox
            employeeUnitesShipped(currentEmployee - 1).Text += currentEntry.ToString & vbCrLf

            'PROCESSING

            ' When the currentday is the last day in the week
            If currentDay = NumberofDays Then

                ' Calculate the average shipped of the current employee and displays it 
                For dayCounter As Integer = 1 To NumberofDays
                    runningTotal += unitsShipped(dayCounter - 1, currentEmployee - 1)
                Next

                average = CDbl(runningTotal / NumberofDays)
                totalAverage += average        ' 
                employeeAverage(currentEmployee - 1).Text = "Average: " & Math.Round(average, 2).ToString("n2")
            End If

            ' When it comes to the last day of the last employee, calculate the per day average shipped of the 3 employees and displays it 
            If currentDay = NumberofDays Then
                If currentEmployee = NumberofEmployees Then
                    dayAverage = CDbl(totalAverage / NumberofEmployees)
                    lbTotalAverage.Text = "Average per day: " & Math.Round(dayAverage, 2).ToString("n2")

                    ' Disabled the entry textbox and calculate button, focus on the reset button
                    tbUnitsShippedEnter.ReadOnly = True
                    btnEnter.Enabled = False
                    btnReset.Focus()
                    currentDay = NumberofDays + 1
                    UpdateDay(currentDay)
                    employeeArray(currentEmployee - 1).Font = New Font(employeeArray(currentEmployee - 1).Font, FontStyle.Bold)
                Else
                    ' If it is not the last employee, reset the current day to Day 1 and move to the next employee
                    currentDay = 1
                    UpdateDay(currentDay)
                    currentEmployee += 1
                    employeeArray(currentEmployee - 1).Font = New Font(employeeArray(currentEmployee - 1).Font, FontStyle.Bold)
                    employeeArray(currentEmployee - 2).Font = New Font(employeeArray(currentEmployee - 2).Font, FontStyle.Regular)
                End If

            Else
                ' Move to the next day
                currentDay += 1
                UpdateDay(currentDay)

            End If

        End If

    End Sub

    ''' <summary>
    ''' Clears all textboxes of grades and clear all letter grade labels
    ''' </summary>
    Private Sub SetDefaults()
        ' Clear the input textbox
        tbUnitsShippedEnter.Text = ""
        tbUnitsShippedEmployee1.Text = ""
        tbUnitsShippedEmployee2.Text = ""
        tbUnitsShippedEmployee3.Text = ""

        ' Clear the calculated label
        lbAverageEmployee1.Text = ""
        lbAverageEmployee2.Text = ""
        lbAverageEmployee3.Text = ""
        lbTotalAverage.Text = ""

        ' Reset the label day back to Day 1
        currentDay = 1
        UpdateDay(currentDay)
        currentEmployee = 1
        lbDay.Text = "Day " & currentDay

        'Focus on the input textbox delete the read-only property
        tbUnitsShippedEnter.Focus()
        tbUnitsShippedEnter.ReadOnly = False

        'Enable the enter btton
        btnEnter.Enabled = True

        'Bold the lbEmployee1 & unbold the lbEmployee3
        lbEmployee1.Font = New Font(lbEmployee1.Font, FontStyle.Bold)
        lbEmployee3.Font = New Font(lbEmployee3.Font, FontStyle.Regular)

        'Set the totalaverage and the per day average back to 0
        totalAverage = 0.0
        dayAverage = 0.0

    End Sub

    ''' <summary>
    ''' This useful event handler reset the all entries
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ' Use the SetDefaults() function
        SetDefaults()

    End Sub


End Class
