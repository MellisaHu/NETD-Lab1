﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuNew = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOpen = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSaveAs = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClose = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCut = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCopy = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPaste = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuWindows = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCascade = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTileVertical = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuTileHorizontal = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAverageUnits = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.ttpMDITextEditor = New System.Windows.Forms.ToolTip(Me.components)
        Me.Tools = New System.Windows.Forms.ToolStrip()
        Me.btnNew = New System.Windows.Forms.ToolStripButton()
        Me.btnOpen = New System.Windows.Forms.ToolStripButton()
        Me.btnSave = New System.Windows.Forms.ToolStripButton()
        Me.sbMain = New System.Windows.Forms.StatusStrip()
        Me.lbDate = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lbDescription = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lbTime = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lbEmpty = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMain.SuspendLayout()
        Me.Tools.SuspendLayout()
        Me.sbMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnuMain
        '
        Me.mnuMain.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuEdit, Me.mnuWindows, Me.mnuHelp})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Size = New System.Drawing.Size(964, 33)
        Me.mnuMain.TabIndex = 0
        Me.mnuMain.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuNew, Me.mnuOpen, Me.mnuSave, Me.mnuSaveAs, Me.mnuClose, Me.mnuExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(50, 29)
        Me.mnuFile.Text = "&File"
        Me.mnuFile.ToolTipText = "Click to show the ""File"" options"
        '
        'mnuNew
        '
        Me.mnuNew.Image = Global.MDITextEditor.My.Resources.Resources.newIcon
        Me.mnuNew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.mnuNew.Name = "mnuNew"
        Me.mnuNew.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.mnuNew.Size = New System.Drawing.Size(205, 30)
        Me.mnuNew.Text = "&New"
        Me.mnuNew.ToolTipText = "Click to create a new child form"
        '
        'mnuOpen
        '
        Me.mnuOpen.Image = Global.MDITextEditor.My.Resources.Resources.openIcon
        Me.mnuOpen.Name = "mnuOpen"
        Me.mnuOpen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.mnuOpen.Size = New System.Drawing.Size(205, 30)
        Me.mnuOpen.Text = "&Open"
        Me.mnuOpen.ToolTipText = "Click to open a new file as a child form"
        '
        'mnuSave
        '
        Me.mnuSave.Image = Global.MDITextEditor.My.Resources.Resources.saveIcon
        Me.mnuSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.mnuSave.Name = "mnuSave"
        Me.mnuSave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnuSave.Size = New System.Drawing.Size(205, 30)
        Me.mnuSave.Text = "&Save"
        Me.mnuSave.ToolTipText = "Click to save the child form"
        '
        'mnuSaveAs
        '
        Me.mnuSaveAs.Name = "mnuSaveAs"
        Me.mnuSaveAs.Size = New System.Drawing.Size(205, 30)
        Me.mnuSaveAs.Text = "Save &As"
        Me.mnuSaveAs.ToolTipText = "Click to save the child form as a new file"
        '
        'mnuClose
        '
        Me.mnuClose.Name = "mnuClose"
        Me.mnuClose.Size = New System.Drawing.Size(205, 30)
        Me.mnuClose.Text = "&Close"
        Me.mnuClose.ToolTipText = "Click to close the selected child form"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(205, 30)
        Me.mnuExit.Text = "E&xit"
        Me.mnuExit.ToolTipText = "Click to exit the application"
        '
        'mnuEdit
        '
        Me.mnuEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuCut, Me.mnuCopy, Me.mnuPaste, Me.SelectAllToolStripMenuItem})
        Me.mnuEdit.Name = "mnuEdit"
        Me.mnuEdit.Size = New System.Drawing.Size(54, 29)
        Me.mnuEdit.Text = "&Edit"
        Me.mnuEdit.ToolTipText = "Click to choose the ""Edit"" options"
        '
        'mnuCut
        '
        Me.mnuCut.Name = "mnuCut"
        Me.mnuCut.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.mnuCut.Size = New System.Drawing.Size(200, 30)
        Me.mnuCut.Text = "Cu&t"
        Me.mnuCut.ToolTipText = "Click to cut the selected text"
        '
        'mnuCopy
        '
        Me.mnuCopy.Name = "mnuCopy"
        Me.mnuCopy.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.mnuCopy.Size = New System.Drawing.Size(200, 30)
        Me.mnuCopy.Text = "&Copy"
        Me.mnuCopy.ToolTipText = "Click to copy the selected text"
        '
        'mnuPaste
        '
        Me.mnuPaste.Name = "mnuPaste"
        Me.mnuPaste.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.mnuPaste.Size = New System.Drawing.Size(200, 30)
        Me.mnuPaste.Text = "&Paste"
        Me.mnuPaste.ToolTipText = "Click to paste the selected text"
        '
        'mnuWindows
        '
        Me.mnuWindows.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuCascade, Me.mnuTileVertical, Me.mnuTileHorizontal, Me.mnuAverageUnits})
        Me.mnuWindows.Name = "mnuWindows"
        Me.mnuWindows.Size = New System.Drawing.Size(98, 29)
        Me.mnuWindows.Text = "&Windows"
        Me.mnuWindows.ToolTipText = "Click to choose the ""Windows"" options"
        '
        'mnuCascade
        '
        Me.mnuCascade.Name = "mnuCascade"
        Me.mnuCascade.Size = New System.Drawing.Size(209, 30)
        Me.mnuCascade.Text = "Cascade"
        Me.mnuCascade.ToolTipText = "Click to cascade all opened child forms"
        '
        'mnuTileVertical
        '
        Me.mnuTileVertical.Name = "mnuTileVertical"
        Me.mnuTileVertical.Size = New System.Drawing.Size(209, 30)
        Me.mnuTileVertical.Text = "Tile Vertical"
        Me.mnuTileVertical.ToolTipText = "Click to set the child forms displayed in vertical order"
        '
        'mnuTileHorizontal
        '
        Me.mnuTileHorizontal.Name = "mnuTileHorizontal"
        Me.mnuTileHorizontal.Size = New System.Drawing.Size(209, 30)
        Me.mnuTileHorizontal.Text = "Tile Horizontal"
        Me.mnuTileHorizontal.ToolTipText = "Click to set the child forms displayed in horizontal order"
        '
        'mnuAverageUnits
        '
        Me.mnuAverageUnits.Name = "mnuAverageUnits"
        Me.mnuAverageUnits.Size = New System.Drawing.Size(209, 30)
        Me.mnuAverageUnits.Text = "Average &Units"
        Me.mnuAverageUnits.ToolTipText = "Click to open the ""Average Units"" project"
        '
        'mnuHelp
        '
        Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAbout})
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(61, 29)
        Me.mnuHelp.Text = "Help"
        Me.mnuHelp.ToolTipText = "Click to choose the ""Help"" options"
        '
        'mnuAbout
        '
        Me.mnuAbout.Name = "mnuAbout"
        Me.mnuAbout.Size = New System.Drawing.Size(146, 30)
        Me.mnuAbout.Text = "About"
        Me.mnuAbout.ToolTipText = "Click to show the informantion of the inventor of this application"
        '
        'Tools
        '
        Me.Tools.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.Tools.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnNew, Me.btnOpen, Me.btnSave})
        Me.Tools.Location = New System.Drawing.Point(0, 33)
        Me.Tools.Name = "Tools"
        Me.Tools.Size = New System.Drawing.Size(964, 31)
        Me.Tools.TabIndex = 1
        Me.Tools.Text = "ToolStrip1"
        '
        'btnNew
        '
        Me.btnNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnNew.Image = Global.MDITextEditor.My.Resources.Resources.newIcon
        Me.btnNew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(28, 28)
        Me.btnNew.ToolTipText = "Click to create a new child form"
        '
        'btnOpen
        '
        Me.btnOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnOpen.Image = Global.MDITextEditor.My.Resources.Resources.openIcon
        Me.btnOpen.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnOpen.Name = "btnOpen"
        Me.btnOpen.Size = New System.Drawing.Size(28, 28)
        Me.btnOpen.ToolTipText = "Click to open a file"
        '
        'btnSave
        '
        Me.btnSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnSave.Image = Global.MDITextEditor.My.Resources.Resources.saveIcon
        Me.btnSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(28, 28)
        Me.btnSave.ToolTipText = "Click to save the text in the selected child form"
        '
        'sbMain
        '
        Me.sbMain.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.sbMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbDate, Me.lbDescription, Me.lbTime, Me.lbEmpty})
        Me.sbMain.Location = New System.Drawing.Point(0, 571)
        Me.sbMain.Name = "sbMain"
        Me.sbMain.Size = New System.Drawing.Size(964, 34)
        Me.sbMain.TabIndex = 2
        Me.ttpMDITextEditor.SetToolTip(Me.sbMain, "Display the current date, time and the number of the opened child forms")
        '
        'lbDate
        '
        Me.lbDate.AutoSize = False
        Me.lbDate.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lbDate.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner
        Me.lbDate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.lbDate.Name = "lbDate"
        Me.lbDate.Size = New System.Drawing.Size(80, 29)
        Me.lbDate.Text = "Date"
        Me.lbDate.ToolTipText = "Display the current date"
        '
        'lbDescription
        '
        Me.lbDescription.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lbDescription.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner
        Me.lbDescription.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.lbDescription.Name = "lbDescription"
        Me.lbDescription.Size = New System.Drawing.Size(371, 29)
        Me.lbDescription.Spring = True
        Me.lbDescription.Text = "Description"
        Me.lbDescription.ToolTipText = "Display the number of the opened child form"
        '
        'lbTime
        '
        Me.lbTime.AutoSize = False
        Me.lbTime.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lbTime.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner
        Me.lbTime.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.lbTime.Name = "lbTime"
        Me.lbTime.Size = New System.Drawing.Size(80, 29)
        Me.lbTime.Text = "Time"
        Me.lbTime.ToolTipText = "Display the current time"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'lbEmpty
        '
        Me.lbEmpty.Name = "lbEmpty"
        Me.lbEmpty.Size = New System.Drawing.Size(371, 29)
        Me.lbEmpty.Spring = True
        Me.lbEmpty.Text = " "
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(230, 30)
        Me.SelectAllToolStripMenuItem.Text = "Select All"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(964, 605)
        Me.Controls.Add(Me.sbMain)
        Me.Controls.Add(Me.Tools)
        Me.Controls.Add(Me.mnuMain)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.mnuMain
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Form"
        Me.ttpMDITextEditor.SetToolTip(Me, "This form is used to contain multiple child forms")
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        Me.Tools.ResumeLayout(False)
        Me.Tools.PerformLayout()
        Me.sbMain.ResumeLayout(False)
        Me.sbMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents mnuMain As MenuStrip
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents mnuNew As ToolStripMenuItem
    Friend WithEvents mnuSave As ToolStripMenuItem
    Friend WithEvents mnuSaveAs As ToolStripMenuItem
    Friend WithEvents mnuClose As ToolStripMenuItem
    Friend WithEvents mnuExit As ToolStripMenuItem
    Friend WithEvents mnuEdit As ToolStripMenuItem
    Friend WithEvents mnuCut As ToolStripMenuItem
    Friend WithEvents mnuCopy As ToolStripMenuItem
    Friend WithEvents mnuPaste As ToolStripMenuItem
    Friend WithEvents mnuWindows As ToolStripMenuItem
    Friend WithEvents mnuCascade As ToolStripMenuItem
    Friend WithEvents mnuTileVertical As ToolStripMenuItem
    Friend WithEvents mnuTileHorizontal As ToolStripMenuItem
    Friend WithEvents mnuAverageUnits As ToolStripMenuItem
    Friend WithEvents mnuHelp As ToolStripMenuItem
    Friend WithEvents mnuAbout As ToolStripMenuItem
    Friend WithEvents ttpMDITextEditor As ToolTip
    Friend WithEvents Tools As ToolStrip
    Friend WithEvents btnNew As ToolStripButton
    Friend WithEvents btnOpen As ToolStripButton
    Friend WithEvents btnSave As ToolStripButton
    Friend WithEvents sbMain As StatusStrip
    Friend WithEvents lbDate As ToolStripStatusLabel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents lbDescription As ToolStripStatusLabel
    Friend WithEvents lbTime As ToolStripStatusLabel
    Friend WithEvents mnuOpen As ToolStripMenuItem
    Friend WithEvents lbEmpty As ToolStripStatusLabel
    Friend WithEvents SelectAllToolStripMenuItem As ToolStripMenuItem
End Class
