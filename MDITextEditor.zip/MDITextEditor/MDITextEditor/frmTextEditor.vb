﻿Public Class frmTextEditor
    Private Sub frmTextEditor_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MdiParent = frmMain
    End Sub
End Class