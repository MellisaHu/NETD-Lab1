﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAverageUnitsShippedEmployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lbUnits = New System.Windows.Forms.Label()
        Me.tbUnitsShippedEnter = New System.Windows.Forms.TextBox()
        Me.lbDay = New System.Windows.Forms.Label()
        Me.tbUnitsShippedEmployee1 = New System.Windows.Forms.TextBox()
        Me.lbTotalAverage = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ttpUintsShippedTips = New System.Windows.Forms.ToolTip(Me.components)
        Me.lbAverageEmployee1 = New System.Windows.Forms.Label()
        Me.lbAverageEmployee2 = New System.Windows.Forms.Label()
        Me.tbUnitsShippedEmployee2 = New System.Windows.Forms.TextBox()
        Me.lbAverageEmployee3 = New System.Windows.Forms.Label()
        Me.tbUnitsShippedEmployee3 = New System.Windows.Forms.TextBox()
        Me.lbEmployee1 = New System.Windows.Forms.Label()
        Me.lbEmployee2 = New System.Windows.Forms.Label()
        Me.lbEmployee3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lbUnits
        '
        Me.lbUnits.Location = New System.Drawing.Point(8, 65)
        Me.lbUnits.Name = "lbUnits"
        Me.lbUnits.Size = New System.Drawing.Size(73, 23)
        Me.lbUnits.TabIndex = 1
        Me.lbUnits.Text = "&Units:"
        Me.lbUnits.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbUnitsShippedEnter
        '
        Me.tbUnitsShippedEnter.Location = New System.Drawing.Point(86, 65)
        Me.tbUnitsShippedEnter.Name = "tbUnitsShippedEnter"
        Me.tbUnitsShippedEnter.Size = New System.Drawing.Size(76, 26)
        Me.tbUnitsShippedEnter.TabIndex = 2
        Me.ttpUintsShippedTips.SetToolTip(Me.tbUnitsShippedEnter, "Enter the units shipped for the day")
        '
        'lbDay
        '
        Me.lbDay.Location = New System.Drawing.Point(8, 27)
        Me.lbDay.Name = "lbDay"
        Me.lbDay.Size = New System.Drawing.Size(75, 23)
        Me.lbDay.TabIndex = 0
        Me.lbDay.Text = "Day 1"
        Me.lbDay.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbUnitsShippedEmployee1
        '
        Me.tbUnitsShippedEmployee1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.tbUnitsShippedEmployee1.Location = New System.Drawing.Point(16, 131)
        Me.tbUnitsShippedEmployee1.Multiline = True
        Me.tbUnitsShippedEmployee1.Name = "tbUnitsShippedEmployee1"
        Me.tbUnitsShippedEmployee1.ReadOnly = True
        Me.tbUnitsShippedEmployee1.Size = New System.Drawing.Size(184, 187)
        Me.tbUnitsShippedEmployee1.TabIndex = 6
        Me.ttpUintsShippedTips.SetToolTip(Me.tbUnitsShippedEmployee1, "All daily units shipped dipalyed here")
        '
        'lbTotalAverage
        '
        Me.lbTotalAverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbTotalAverage.Location = New System.Drawing.Point(16, 364)
        Me.lbTotalAverage.Name = "lbTotalAverage"
        Me.lbTotalAverage.Size = New System.Drawing.Size(585, 23)
        Me.lbTotalAverage.TabIndex = 12
        Me.lbTotalAverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpUintsShippedTips.SetToolTip(Me.lbTotalAverage, "dispaly the average of the units shipped")
        '
        'btnEnter
        '
        Me.btnEnter.AutoSize = True
        Me.btnEnter.Location = New System.Drawing.Point(12, 402)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(184, 30)
        Me.btnEnter.TabIndex = 13
        Me.btnEnter.Text = "&Enter"
        Me.ttpUintsShippedTips.SetToolTip(Me.btnEnter, "Click to enter this day's units shipped")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.AutoSize = True
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(217, 402)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(184, 30)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "&Reset"
        Me.ttpUintsShippedTips.SetToolTip(Me.btnReset, "Click to reset all entries")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.AutoSize = True
        Me.btnExit.Location = New System.Drawing.Point(417, 402)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(184, 30)
        Me.btnExit.TabIndex = 15
        Me.btnExit.Text = "E&xit"
        Me.ttpUintsShippedTips.SetToolTip(Me.btnExit, "Click to close the application")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lbAverageEmployee1
        '
        Me.lbAverageEmployee1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbAverageEmployee1.Location = New System.Drawing.Point(16, 331)
        Me.lbAverageEmployee1.Name = "lbAverageEmployee1"
        Me.lbAverageEmployee1.Size = New System.Drawing.Size(184, 23)
        Me.lbAverageEmployee1.TabIndex = 9
        Me.lbAverageEmployee1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpUintsShippedTips.SetToolTip(Me.lbAverageEmployee1, "dispaly the average of the units shipped of enployee 1")
        '
        'lbAverageEmployee2
        '
        Me.lbAverageEmployee2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbAverageEmployee2.Location = New System.Drawing.Point(217, 331)
        Me.lbAverageEmployee2.Name = "lbAverageEmployee2"
        Me.lbAverageEmployee2.Size = New System.Drawing.Size(184, 23)
        Me.lbAverageEmployee2.TabIndex = 10
        Me.lbAverageEmployee2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpUintsShippedTips.SetToolTip(Me.lbAverageEmployee2, "dispaly the average of the units shipped of enployee 2")
        '
        'tbUnitsShippedEmployee2
        '
        Me.tbUnitsShippedEmployee2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.tbUnitsShippedEmployee2.Location = New System.Drawing.Point(217, 131)
        Me.tbUnitsShippedEmployee2.Multiline = True
        Me.tbUnitsShippedEmployee2.Name = "tbUnitsShippedEmployee2"
        Me.tbUnitsShippedEmployee2.ReadOnly = True
        Me.tbUnitsShippedEmployee2.Size = New System.Drawing.Size(184, 187)
        Me.tbUnitsShippedEmployee2.TabIndex = 7
        Me.ttpUintsShippedTips.SetToolTip(Me.tbUnitsShippedEmployee2, "All daily units shipped dipalyed here")
        '
        'lbAverageEmployee3
        '
        Me.lbAverageEmployee3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbAverageEmployee3.Location = New System.Drawing.Point(417, 331)
        Me.lbAverageEmployee3.Name = "lbAverageEmployee3"
        Me.lbAverageEmployee3.Size = New System.Drawing.Size(184, 23)
        Me.lbAverageEmployee3.TabIndex = 11
        Me.lbAverageEmployee3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttpUintsShippedTips.SetToolTip(Me.lbAverageEmployee3, "dispaly the average of the units shipped of enployee 3")
        '
        'tbUnitsShippedEmployee3
        '
        Me.tbUnitsShippedEmployee3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.tbUnitsShippedEmployee3.Location = New System.Drawing.Point(417, 131)
        Me.tbUnitsShippedEmployee3.Multiline = True
        Me.tbUnitsShippedEmployee3.Name = "tbUnitsShippedEmployee3"
        Me.tbUnitsShippedEmployee3.ReadOnly = True
        Me.tbUnitsShippedEmployee3.Size = New System.Drawing.Size(184, 187)
        Me.tbUnitsShippedEmployee3.TabIndex = 8
        Me.ttpUintsShippedTips.SetToolTip(Me.tbUnitsShippedEmployee3, "All daily units shipped dipalyed here")
        '
        'lbEmployee1
        '
        Me.lbEmployee1.AutoSize = True
        Me.lbEmployee1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbEmployee1.Location = New System.Drawing.Point(58, 105)
        Me.lbEmployee1.Name = "lbEmployee1"
        Me.lbEmployee1.Size = New System.Drawing.Size(102, 20)
        Me.lbEmployee1.TabIndex = 3
        Me.lbEmployee1.Text = "Employee 1"
        '
        'lbEmployee2
        '
        Me.lbEmployee2.AutoSize = True
        Me.lbEmployee2.Location = New System.Drawing.Point(259, 105)
        Me.lbEmployee2.Name = "lbEmployee2"
        Me.lbEmployee2.Size = New System.Drawing.Size(92, 20)
        Me.lbEmployee2.TabIndex = 4
        Me.lbEmployee2.Text = "Employee 2"
        '
        'lbEmployee3
        '
        Me.lbEmployee3.AutoSize = True
        Me.lbEmployee3.Location = New System.Drawing.Point(459, 105)
        Me.lbEmployee3.Name = "lbEmployee3"
        Me.lbEmployee3.Size = New System.Drawing.Size(92, 20)
        Me.lbEmployee3.TabIndex = 5
        Me.lbEmployee3.Text = "Employee 3"
        '
        'frmAverageUnitsShippedEmployee
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(614, 445)
        Me.Controls.Add(Me.lbEmployee3)
        Me.Controls.Add(Me.lbAverageEmployee3)
        Me.Controls.Add(Me.tbUnitsShippedEmployee3)
        Me.Controls.Add(Me.lbEmployee2)
        Me.Controls.Add(Me.lbAverageEmployee2)
        Me.Controls.Add(Me.tbUnitsShippedEmployee2)
        Me.Controls.Add(Me.lbEmployee1)
        Me.Controls.Add(Me.lbAverageEmployee1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lbTotalAverage)
        Me.Controls.Add(Me.tbUnitsShippedEmployee1)
        Me.Controls.Add(Me.lbDay)
        Me.Controls.Add(Me.tbUnitsShippedEnter)
        Me.Controls.Add(Me.lbUnits)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAverageUnitsShippedEmployee"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Shipped By Employee"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbUnits As Label
    Friend WithEvents tbUnitsShippedEnter As TextBox
    Friend WithEvents lbDay As Label
    Friend WithEvents tbUnitsShippedEmployee1 As TextBox
    Friend WithEvents lbTotalAverage As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ttpUintsShippedTips As ToolTip
    Friend WithEvents lbAverageEmployee1 As Label
    Friend WithEvents lbEmployee1 As Label
    Friend WithEvents lbEmployee2 As Label
    Friend WithEvents lbAverageEmployee2 As Label
    Friend WithEvents tbUnitsShippedEmployee2 As TextBox
    Friend WithEvents lbEmployee3 As Label
    Friend WithEvents lbAverageEmployee3 As Label
    Friend WithEvents tbUnitsShippedEmployee3 As TextBox
End Class
